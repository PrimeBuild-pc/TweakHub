# 🚀 TweakHub Installation Guide

## 📋 **System Requirements**

- **Operating System**: Windows 10 (version 1903 or later) or Windows 11
- **Architecture**: x64 (64-bit)
- **RAM**: 4 GB minimum, 8 GB recommended
- **Storage**: 200 MB free space
- **Administrator Privileges**: Required for full functionality

## ⚡ **Quick Installation**

### **Option 1: Standalone Executable (Recommended)**
1. **Download** `TweakHub.exe` from the latest release
2. **Right-click** on `TweakHub.exe` and select **"Run as administrator"**
3. **Allow** UAC prompt when requested
4. **Enjoy** - No additional installation required!

### **Option 2: Manual Installation**
1. **Create** a folder: `C:\Program Files\TweakHub\`
2. **Copy** `TweakHub.exe` to this folder
3. **Create** a desktop shortcut (optional)
4. **Run** as administrator for full functionality

## 🔧 **First Run Setup**

1. **Administrator Privileges**: TweakHub will prompt for elevation on first run
2. **Theme Selection**: The application starts with a dark theme by default
3. **System Scan**: Initial system analysis may take 30-60 seconds
4. **Ready to Use**: Navigate through tabs to access different features

## 🛡️ **Security & Safety**

- **Windows Defender**: May flag the executable initially (false positive)
- **Antivirus**: Add TweakHub to your antivirus whitelist if needed
- **Registry Backup**: TweakHub automatically creates backups before changes
- **Safe Mode**: All tweaks can be reverted using the application

## 🎯 **Key Features Access**

| **Tab** | **Purpose** | **Admin Required** |
|---------|-------------|-------------------|
| **Registry Tweaks** | Performance optimizations | ✅ Yes |
| **External Tools** | Download system utilities | ❌ No |
| **Automated Scripts** | Bulk optimizations | ✅ Yes |
| **Quick Access** | System settings shortcuts | ❌ No |
| **System Monitor** | Real-time metrics | ❌ No |

## 🔄 **Updates**

- **Automatic**: TweakHub checks for updates on startup
- **Manual**: Visit the GitHub releases page for latest versions
- **Notifications**: Update prompts appear in the application

## ❓ **Troubleshooting**

### **Common Issues**

**"Application requires elevation"**
- Solution: Right-click and "Run as administrator"

**"Some features not working"**
- Solution: Ensure administrator privileges are granted

**"Antivirus blocking execution"**
- Solution: Add TweakHub.exe to antivirus whitelist

**"System monitoring not showing data"**
- Solution: Wait 30-60 seconds for initial system scan

### **Support**

- **GitHub Issues**: Report bugs and feature requests
- **Documentation**: Check README.md for detailed information
- **Community**: Join discussions in GitHub repository

## 🗑️ **Uninstallation**

1. **Close** TweakHub application
2. **Delete** `TweakHub.exe` from its location
3. **Remove** desktop shortcuts (if created)
4. **Optional**: Registry changes remain unless manually reverted

---

**⚠️ Important**: Always run TweakHub as administrator for full functionality. The application is designed to be portable and doesn't require traditional installation.
